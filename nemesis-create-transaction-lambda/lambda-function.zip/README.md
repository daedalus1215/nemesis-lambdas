# nemesis-create-transaction-lambda

zip -r ./lambda-function.zip .